package com.testassignment.resourace;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ObjectReposistory {

	

	public ObjectReposistory() throws IOException {
		Properties obj = new Properties();					
	    FileInputStream objfile = new FileInputStream(System.getProperty("user.dir")+"\\locator.properties");									
	    obj.load(objfile);
	  String baseurl = obj.getProperty("baseUrl");
	   System.out.println(baseurl);
	    
	}

	public static void main(String[] args) throws Throwable {
		ObjectReposistory t = new ObjectReposistory();
		System.out.println("properties file");

	}

}
