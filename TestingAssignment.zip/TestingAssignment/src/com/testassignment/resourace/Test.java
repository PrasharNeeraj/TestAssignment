package com.testassignment.resourace;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Test {

	

	private static char[] mobileTesting;

	public Test() throws IOException {
		Properties obj = new Properties();					
	    FileInputStream objfile = new FileInputStream(System.getProperty("user.dir")+"\\locator.properties");									
	    obj.load(objfile);
	  String mobileTesting = obj.getProperty("baseUrl");
	   // System.out.println(mobileTesting);
	    
	}

	public static void main(String[] args) throws Throwable {
		Test t = new Test();
		System.out.println(mobileTesting);

	}

}
