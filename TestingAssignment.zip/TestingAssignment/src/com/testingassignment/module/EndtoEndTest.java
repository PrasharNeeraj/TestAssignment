package com.testingassignment.module;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.internal.TestResult;
import org.testng.log4testng.Logger;
import org.testng.reporters.TextReporter;

import com.testassignment.ccommonutils.Utils;

public class EndtoEndTest {
	// private String baseUrl = "http://automationpractice.com/index.php";

	// private static Logger Log = Logger.getLogger(Log.class.getName());
	private String chromedriver = "C:\\Users\\pandn013\\Documents\\testing project\\chromedriver.exe";

	@Test

	public void Login() throws InterruptedException, IOException {
		System.setProperty("webdriver.chrome.driver", chromedriver);
		// Load the properties File
		Properties obj = new Properties();
		FileInputStream objfile = new FileInputStream(System.getProperty("user.dir") + "\\locator.properties");
		obj.load(objfile);
		String baseurl = obj.getProperty("baseUrl");
		System.out.println(baseurl);

		// lounch chrome browser
		WebDriver driver = new ChromeDriver();
		driver.get(baseurl);
		driver.manage().window().maximize();

		// verify the title of page
		String title = driver.getTitle();
		Assert.assertEquals("My Store", title);
		// driver.quit();

		// create account
		Thread.sleep(5000);

		driver.findElement(By.xpath("//a[@class='login']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

		// Create random mail id
		// Utils ut =new Utils();
		String randamvalue = Utils.randomAlphaNumeric(10);
		String randamvalue1 = randamvalue + "@gmail.com";
		System.out.println(randamvalue1);
		// Enter email id
		driver.findElement(By.id("email_create")).sendKeys(randamvalue1);
		driver.findElement(By.id("SubmitCreate")).click();

		System.out.println("<-------Create Account--------->");
		// enter firstName , lastName and password
		driver.findElement(By.id("id_gender1")).click();
		driver.findElement(By.id("customer_firstname")).sendKeys(Utils.randomAlphaNumeric(6));
		driver.findElement(By.id("customer_lastname")).sendKeys(Utils.randomAlphaNumeric(5));
		driver.findElement(By.id("passwd")).sendKeys("password");
		Thread.sleep(1000);

		// select days,month and years
		Select days = new Select(driver.findElement(By.id("days")));
		days.selectByIndex(4);
		Select months = new Select(driver.findElement(By.id("months")));
		months.selectByIndex(3);
		Select years = new Select(driver.findElement(By.id("years")));
		years.selectByIndex(6);

		// Address
		driver.findElement(By.id("newsletter")).click();
		driver.findElement(By.id("optin")).click();
		driver.findElement(By.id("company")).sendKeys("TestCompany");
		driver.findElement(By.id("address1")).sendKeys(Utils.randomAlphaNumeric(3) + "blockqq c sector 20 thane");
		driver.findElement(By.id("address2")).sendKeys(Utils.randomAlphaNumeric(2) + "buildingaa 5");
		driver.findElement(By.id("city")).sendKeys(Utils.randomAlphaNumeric(11) + "Mumbai");

		// select state
		Select state = new Select(driver.findElement(By.id("id_state")));
		state.selectByIndex(3);

		// Enter pincode,phone no and other information
		driver.findElement(By.id("postcode")).sendKeys("40032");
		driver.findElement(By.id("other")).sendKeys("additional information");
		driver.findElement(By.id("phone")).sendKeys("9876543210");
		driver.findElement(By.id("phone_mobile")).sendKeys("1234567809");
		driver.findElement(By.id("alias")).sendKeys("alias test data ");
		driver.findElement(By.id("submitAccount")).sendKeys("alias test data ");

		// click again in sign in
		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@class='login']")).click();
		driver.findElement(By.id("email")).sendKeys(randamvalue1);
		driver.findElement(By.id("passwd")).sendKeys("password");
		driver.findElement(By.id("SubmitLogin")).click();

		driver.findElement(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[1]/a")).click();

		// Mouseover on submit button
		Actions action = new Actions(driver);
		WebElement quickview = driver
				.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li[1]/div/div[1]/div/a[1]/img"));
		action.moveToElement(quickview).perform();
		Thread.sleep(2000);

		// click on more
		driver.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li[1]/div/div[2]/div[2]/a[2]/span")).click();

		System.out.println("<-------TestStep--------->");
		driver.findElement(By.id("quantity_wanted_p")).click();
		driver.findElement(By.id("add_to_cart")).click();
		driver.findElement(By.id("layer_cart")).click();

		// verify Total Ammount and proccedto addd card
		System.out.println("<-------Pyament step-------->");
		driver.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a/span")).click();
		// button btn btn-default standard-checkout button-medium
		driver.findElement(By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"center_column\"]/form/p/button/span")).click();
		driver.findElement(By.id("cgv")).click();

		driver.findElement(By.xpath("//*[@id=\"form\"]/p/button/span")).click();
		//Total ammount 
		String TotalAmount = driver.findElement(By.id("total_price")).getText();
		System.out.println("total ammount =  " + TotalAmount);
		
		driver.findElement(By.xpath("//*[@id=\"HOOK_PAYMENT\"]/div[1]/div/p/a")).click();
		driver.findElement(By.xpath("//*[@id=\"cart_navigation\"]/button/span")).click();
		
		
        System.out.println("<-------ORDER HISTORY-------->");
		driver.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"center_column\"]/div/div[1]/ul/li[1]/a/span")).click();
		String HistoryTotalAmunt = driver.findElement(By.xpath("//*[@id=\"order-list\"]/tbody/tr/td[3]")).getText();
		
		// Validation of total ammount and history
		Assert.assertEquals(TotalAmount, HistoryTotalAmunt);
		System.out.println("history  total ammount "+HistoryTotalAmunt);

		
	}

}
